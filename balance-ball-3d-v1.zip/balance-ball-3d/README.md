# Balance Ball Mini - Android APK Project

Ye PUBG ka chhota top-down mini clone hai, WebView mein chalta hai.
Game file: app/src/main/assets/balance-ball.html

Build (GitHub Actions, phone se):
1. GitHub par naya public repo banao, naam: pubg-clone
2. Is project ki zip upload karo
3. .github/workflows/android.yml file banao (neeche diya gaya workflow)
4. Actions mein build chalega, phir artifact se app-debug.apk download karo
5. Phone mein install karo, koi special permission nahi chahiye

Workflow:
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: unzip -o pubg-clone-v1.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: 8.2
      - run: cd pubg-clone && gradle assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: pubg-clone-apk
          path: pubg-clone/app/build/outputs/apk/debug/app-debug.apk
